
# Zango AI Enterprise

## Features
- React Chat UI
- Netlify Functions backend
- Ready for Gemini integration
- Firebase-ready structure

## Deploy
1. npm install
2. npm run build
3. Deploy to Netlify
