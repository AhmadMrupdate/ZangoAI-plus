
exports.handler = async (event) => {
  try {
    const { message } = JSON.parse(event.body);

    // TODO: Replace with Gemini API call
    const reply = `Zango AI (mock response): ${message}`;

    return {
      statusCode: 200,
      body: JSON.stringify({ reply })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
